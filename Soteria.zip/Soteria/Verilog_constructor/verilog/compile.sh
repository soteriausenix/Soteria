#!/bin/bash
mkdir -p syn
# Synthesize this design
design_vision -no_gui -f compile.dcsh
