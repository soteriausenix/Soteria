# Soteria

## Architecture Search

First, a suitable model for a given dataset is searched using DARTS architecture search. Then, the model is trained fully. This will take a few hours, depending on the test machine configuration. The included code uses the 'CIFAR10' dataset. In the `Architecture_Search` directory:

#### Search model
    python3 train_search.py

#### Train searched model
    python3 train.py


## Standard TNN - train

Included is a simple Ternary Neural Network to demonstrate how TNNs work, using the 'MNIST' dataset for simplicity. To train, simply run in the `TNN` directory:

    python3 main.py


## Build Verilog

To build the SystemVerilog code from the saved model architecture and weights, in the `Verilog_constructor` directory, simply run:

    python3 convert_verilog.py

Make sure to set values `input_size_lh` (LENGTH/WIDTH of input) and `input_size_d` (DEPTH of input) in file `convert_verilog.py` at line nos. 54, 55 before executing the build script. These values correspond to the first ternary layer of the architecture.

## Synthesize

Synthesize the main file `multlayer1.sv` into a netlist file using Synopsys DC.

## Run Garbled Circuit test

1. Create the 'Simple Circuit Description' file from the synthesized netlist file using `V2SCD_Main` utility that ships with TinyGarble package.
2. Run the Garbled Circuit using the `TinyGarble` utility.