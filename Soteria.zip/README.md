# Architecture Search

First, a suitable model for a given dataset is searched using DARTS architecture search. Then, the model is trained fully. This will take a few hours, depending on the test machine configuration. In the `Architecture_Search` directory:

#### Search model
    python3 train_search.py

#### Train searched model
    python3 train.py


# Standard TNN - train

Included is a simple Ternary Neural Network to demonstrate how TNNs work. To train, simply run in the `TNN` directory:

    python3 main_mnist.py


# Build Verilog

To build the SystemVerilog code from the saved model architecture and weights, in the `Verilog_constructor` directory, simply run:

    python3 convert_verilog.py


# Synthesize

Synthesize the main file `multlayer1.sv` into a netlist file using Synopsys DC.

# Run Garbled Circuit test

1. Create the 'Simple Circuit Description' file from the synthesized netlist file using `V2SCD_Main` utility that ships with TinyGarble package.
2. Run the Garbled Circuit using the `TinyGarble` utility.