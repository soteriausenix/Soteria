# Architecture Search

#### Search model
    python3 Architecture_Search/train_search.py

#### Train searched model
    python3 Architecture_Search/train.py


# Standard TNN - train
    python3 TNN/main_mnist.py


# Build Verilog
    python3 Verilog_constructor/buildverilog.py