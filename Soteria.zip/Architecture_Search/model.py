import torch
import torch.nn as nn
from operators2 import *
from utils import *
import numpy as np

PRIMITIVES = [
    'identity',
    'conv_3x3',
    'max_pool_2x2',
    'conv_5x5',
]

inputsize = 32


class Cell(nn.Module): 
    def __init__(self, steps, multiplier, C_prev, C, weight):
        super(Cell, self).__init__()
        self.C = C
        self.incrflag = False
        self.C_prev = C_prev
        self.steps = steps
        self.multiplier = multiplier
        self.arch = self._parse_arch_(weight)
        self._compile_(self.arch)

    def _parse_arch_(self, weight):
        arch = []
        for i_b in range(self.steps):
            for i_n in range(2):
                W = -1*(weight[i_b*2 + i_n].copy())
                i_op_best = np.argmax(W)
                op_chosen = PRIMITIVES[i_op_best]
                arch.append((op_chosen, i_b*2 + i_n))

        return arch

    def _compile_(self, arch):
        global inputsize
        self._ops = nn.ModuleList()
        for (op_name, i_n) in arch:
            c_1, c_2 = self.C_prev, self.C 
            if 'max_pool_2x2' in op_name:
                if inputsize >= 2:
                    inputsize = int(inputsize/2)
                else:
                    self._ops.append(OPS['identity'](c_1, c_2))
                    continue

            self._ops.append(OPS[op_name](c_1, c_2))
            if 'conv' in op_name:
                c_1 = c_2
                self.incrflag = True



    def forward(self, s0):
        stats = [s0]

        for i_b in range(self.steps):
            for i_n in range(2):
                res = self._ops[2*i_b + i_n](stats[2*i_b + i_n])
                stats.append(res)

        return stats[-1]



class NetworkCIFAR(nn.Module):
    def __init__(self, C, num_classes, layers, steps=2, multiplier=2, stem_multiplier=1, arch=None):
        super(NetworkCIFAR, self).__init__()
        self.layers = layers

        stem_multiplier = 1
        C_curr = stem_multiplier*C
        self.stem = nn.Sequential(
            nn.Conv2d(3, C_curr, 3, padding=1, bias=False),
            nn.BatchNorm2d(C_curr),
            nn.CELU()
        )

        C_prev = C_curr
        #C_curr = C_curr*multiplier
        self.cells = nn.ModuleList()
        weight = arch['normal']
        for i_c in range(layers):
            cell = Cell(steps, multiplier, C_prev, C_curr, weight)
            self.cells.append(cell)
            if cell.incrflag:
                C_prev, C_curr = C_curr, multiplier*C_curr
        
        self.post_proc = nn.Sequential(
            nn.BatchNorm2d(C_prev),
            nn.CELU()
        )

        self.fc1 = nn.Linear(C_prev*inputsize*inputsize, 4096, bias = True)

        self.classifier = nn.Sequential(

            nn.BatchNorm1d(4096),
            nn.CELU(),
            nn.Dropout(0.5),
            nn.Linear(4096, 1024, bias=True),
            nn.BatchNorm1d(1024),
            nn.CELU(),
            #nn.Dropout(0.5),
            nn.Linear(1024, 10, bias=True),
            nn.BatchNorm1d(10, affine=False),
            nn.LogSoftmax()
        )

    def forward(self, input):
        logits_aux = None
        s0 = self.stem(input)
        for i, cell in enumerate(self.cells):
            s1 = cell(s0)
            s0 = s1
        out = self.post_proc(s1)
        logits = self.classifier(self.fc1(out.view(out.size(0),-1)))
        return logits, logits_aux