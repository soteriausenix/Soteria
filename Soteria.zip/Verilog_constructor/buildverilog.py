import numpy as np
import verilogcomponents


def getValid(weights):
    valid_weights = []
    for weight in weights:
        if weight in [1, -1]:
            valid_weights.append(1)
        else:
            valid_weights.append(0)
    return valid_weights


def calculateTotalWeights(weights):
    weights_count = 0
    for (layer_id, layer_weights) in weights:
        if layer_id.startswith("Conv"):
            conv_size = int(layer_id.split("_")[1])
            weights_count += conv_size*conv_size
        elif layer_id.startswith("FC"):
            dimensions = layer_id.split("_")[1].split("/")
            layer_input_size = int(dimensions[0])
            layer_size = int(dimensions[1])
            weights_count += layer_input_size*layer_size

    return weights_count    


def buildVerilog(weights_file, ISIZE_H, ISIZE_L, location="./"):
    include = []
    misc_logic = []
    modulecalls = []
    final_input_size = ISIZE_H*ISIZE_L
    weights_file = weights_file.strip().split("\n")

    weights_file = [tuple(x.strip().split(":")) for x in weights_file]
    total_weights = calculateTotalWeights(weights_file)
    e_inp_start = total_weights - 1
    e_inp_end = -1
    counter = 1
    final_output_size = 0
    output_logic = ""
    for (layer_id, layer_weights) in weights_file:
        if layer_id.startswith("Conv"):
            numericid =  layer_id.split("_")[0][4:]
            conv_size = int(layer_id.split("_")[1])
            weights_data = [int(x) for x in layer_weights.strip().split(",")]
            valid_bits = getValid(weights_data)
            num_valid = sum(valid_bits)
            valid_bits = ["1'b" + str(x) for x in valid_bits]
            filename = verilogcomponents.createConv(numid=numericid, ISIZE_L=ISIZE_L, ISIZE_H=ISIZE_H, CONV_SIZE=conv_size, valid=valid_bits, num_valid=num_valid, location=location)
            include.append(filename)
            ISIZE_H = ISIZE_H - (conv_size-1)
            ISIZE_L = ISIZE_L - (conv_size-1)

            modulename = filename.split(".")[0]
            
            g_input_logic = ""

            if output_logic == "":
                g_input_logic = "g_input"
            else:
                g_input_logic = output_logic
            
            if counter == len(weights_file):
                output_logic = "o"
                final_output_size = ISIZE_L*ISIZE_H-1
            else:
                output_logic = modulename + "_o"
                misc_logic.append("bit [{size}:0] {oname};".format(size=str(ISIZE_L*ISIZE_H-1), oname=output_logic))

            e_inp_end = e_inp_start - conv_size*conv_size + 1
            e_input_logic = "e_input[{s}:{e}]".format(s=e_inp_start, e=e_inp_end)
            e_inp_start = e_inp_end - 1
            
            modulecall = """
            {mod} layer{ctr}(
                .clk   (clk),
                .rst   (rst),
                .g_input ({ginp}),
                .e_input ({einp}),
                .o     ({outp})
            );
            """.format(mod=modulename, ctr=counter, ginp=g_input_logic, einp=e_input_logic, outp=output_logic)
            counter += 1
            modulecalls.append(modulecall)

        elif layer_id.startswith("FC"):
            numericid =  layer_id.split("_")[0][2:]
            dimensions = layer_id.split("_")[1].split("/")
            layer_input_size = int(dimensions[0])
            print(layer_input_size, ISIZE_H, ISIZE_L)
            assert layer_input_size == ISIZE_H*ISIZE_L
            layer_size = int(dimensions[1])
            weights_data = [int(x) for x in layer_weights.strip().split(",")]
            valid_bits = getValid(weights_data)
            
            num_valid = np.sum(np.reshape(valid_bits, newshape=(layer_size, layer_input_size)), axis=1)
            valid_bits = ["1'b" + str(x) for x in valid_bits]

            filename = verilogcomponents.createFC(numid=numericid, ISIZE=layer_input_size, LSIZE=layer_size, valid=valid_bits, num_valid=num_valid, location=location)
            include.append(filename)
            ISIZE_L = layer_size
            ISIZE_H = 1

            modulename = filename.split(".")[0]
            
            g_input_logic = ""

            if output_logic == "":
                g_input_logic = "g_input"
            else:
                g_input_logic = output_logic
            
            if counter == len(weights_file):
                final_output_size = layer_size-1
                output_logic = "o"
            else:
                output_logic = modulename + "_o"
                misc_logic.append("bit [{size}:0] {oname};".format(size=str(layer_size-1), oname=output_logic))

            e_inp_end = e_inp_start - layer_input_size*layer_size + 1
            e_input_logic = "e_input[{s}:{e}]".format(s=e_inp_start, e=e_inp_end)
            e_inp_start = e_inp_end - 1
            
            modulecall = """
            {mod} layer{ctr}(
                .clk   (clk),
                .rst   (rst),
                .g_input ({ginp}),
                .e_input ({einp}),
                .o     ({outp})
            );
            """.format(mod=modulename, ctr=counter, ginp=g_input_logic, einp=e_input_logic, outp=output_logic)
            counter += 1
            modulecalls.append(modulecall)
            
        elif layer_id.startswith("Maxp"):
            numericid =  layer_id.split("_")[0][4:]
            pool_size = int(layer_id.split("_")[1])
            filename = verilogcomponents.createMaxpool(numid=numericid, ISIZE_L=ISIZE_L, ISIZE_H=ISIZE_H, POOL_SIZE=pool_size, location=location)
            include.append(filename)
            ISIZE_H = ISIZE_H//pool_size
            ISIZE_L = ISIZE_L//pool_size
            
            modulename = filename.split(".")[0]
            
            g_input_logic = ""

            if output_logic == "":
                g_input_logic = "g_input"
            else:
                g_input_logic = output_logic
            
            if counter == len(weights_file):
                final_output_size = ISIZE_L*ISIZE_H-1
                output_logic = "o"
            else:
                output_logic = modulename + "_o"
                misc_logic.append("bit [{size}:0] {oname};".format(size=str(ISIZE_L*ISIZE_H-1), oname=output_logic))

            modulecall = """
            {mod} layer{ctr}(
                .clk   (clk),
                .rst   (rst),
                .g_input ({ginp}),
                .e_input (1'b0),
                .o     ({outp})
            );
            """.format(mod=modulename, ctr=counter, ginp=g_input_logic, outp=output_logic)
            counter += 1
            modulecalls.append(modulecall)

        elif layer_id.startswith("Pad"):
            numericid =  layer_id.split("_")[0][4:]
            pad_size = int(layer_id.split("_")[1])
            filename = verilogcomponents.createPad(numid=numericid, ISIZE_L=ISIZE_L, ISIZE_H=ISIZE_H, PAD_SIZE=pad_size, location=location)
            include.append(filename)
            ISIZE_H = ISIZE_H + 2*pad_size
            ISIZE_L = ISIZE_L + 2*pad_size
            
            modulename = filename.split(".")[0]
            
            g_input_logic = ""

            if output_logic == "":
                g_input_logic = "g_input"
            else:
                g_input_logic = output_logic
            
            if counter == len(weights_file):
                final_output_size = ISIZE_L*ISIZE_H-1
                output_logic = "o"
            else:
                output_logic = modulename + "_o"
                misc_logic.append("bit [{size}:0] {oname};".format(size=str(ISIZE_L*ISIZE_H-1), oname=output_logic))

            modulecall = """
            {mod} layer{ctr}(
                .clk   (clk),
                .rst   (rst),
                .g_input ({ginp}),
                .e_input (1'b0),
                .o     ({outp})
            );
            """.format(mod=modulename, ctr=counter, ginp=g_input_logic, outp=output_logic)
            counter += 1
            modulecalls.append(modulecall)

    caller_file_code = """
{includes}

module mlnn
#(
    parameter INPUTSIZE = {inputsize}
)
(
    clk,
    rst,
    g_input,
    e_input,
    o
); 

input clk;
input rst;
input bit [INPUTSIZE-1:0] g_input;
input bit [{weightssize}:0] e_input;
output bit [{output_size}:0] o;

{misclogic}

{modulecallslist}

endmodule
    """.format(includes="".join(['`include "' + x + '"\n' for x in include]), inputsize=str(final_input_size), weightssize=str(total_weights-1), output_size=str(final_output_size), misclogic="\n".join(misc_logic), modulecallslist="".join(modulecalls))

    f = open(location + "multlayer1.sv", "w+")
    f.write(caller_file_code)
    f.close()

if __name__=="__main__":
    buildVerilog()