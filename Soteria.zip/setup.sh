#!/bin/bash

apt install software-properties-common -y
add-apt-repository ppa:deadsnakes/ppa


apt-get update
apt-get install python3.7 -y

update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.5 1
update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.7 2

apt-get install python3-pip -y
pip3 install torch==1.4.0 torchvision==0.5.0 -f https://download.pytorch.org/whl/torch_stable.html

apt-get install g++ -y
apt-get install git -y

apt-get install libssl-dev -y
apt-get install libboost-all-dev -y

apt-get install software-properties-common -y
add-apt-repository ppa:george-edison55/cmake-3.x -y

apt-get update -y
apt-get upgrade -y

apt-get install cmake -y

cd ./Soteria
git clone -n https://github.com/esonghori/TinyGarble.git
cd ./TinyGarble
git checkout 21ecca7
chmod +x ./configure
./configure
cd bin
make